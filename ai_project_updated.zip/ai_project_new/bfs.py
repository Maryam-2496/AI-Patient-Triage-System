from collections import deque

hospital_graph = {
    "Reception": ["Registration"],
    "Registration": ["Triage"],
    "Triage": [
        "General OPD",
        "Internal Medicine",
        "Emergency",
        "Cardiology"
    ],
    "Emergency": ["ICU"],
    "Cardiology": ["ICU"]
}

department_map = {
    "Mild": "Genreal OPD",
    "Moderate": "Internal Medicine",
    "Critical": "Emergency"
}

def bfs_route(start,end):
    queue = deque([[start]])
    visited = set()
    while queue:
        path = queue.popleft()
        node = path[-1]
        
        if node == end:
            return path
        
        if node not in visited:
            visited.add(node)

            for neighbor in hospital_graph.get(node,[]):
                new_path = list(path)
                new_path.append(neighbor)
                queue.append(new_path)
    return []
