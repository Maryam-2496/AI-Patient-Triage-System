CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap');

    * { font-family: 'Inter', sans-serif !important; }

    .stApp {
        background: linear-gradient(135deg, #0f0c29, #302b63, #24243e) !important;
        min-height: 100vh;
    }

    /* ── SIDEBAR ── */
    section[data-testid="stSidebar"] {
        background: rgba(255,255,255,0.04) !important;
        backdrop-filter: blur(20px);
        border-right: 1px solid rgba(255,255,255,0.08) !important;
    }
    section[data-testid="stSidebar"] * { color: #e2e8f0 !important; }

    .sidebar-logo {
        text-align: center;
        padding: 28px 16px 20px;
        border-bottom: 1px solid rgba(255,255,255,0.08);
        margin-bottom: 20px;
    }
    .sidebar-logo h2 {
        font-family: 'Poppins', sans-serif !important;
        font-size: 20px !important;
        font-weight: 700 !important;
        color: #ffffff !important;
        margin: 8px 0 4px !important;
    }
    .sidebar-logo p {
        font-size: 11px !important;
        color: #94a3b8 !important;
        margin: 0 !important;
    }

    /* ── PAGE HEADER ── */
    .page-header {
        background: linear-gradient(135deg, rgba(99,102,241,0.2), rgba(168,85,247,0.2));
        border: 1px solid rgba(99,102,241,0.3);
        border-radius: 20px;
        padding: 32px 36px;
        margin-bottom: 28px;
        backdrop-filter: blur(10px);
    }
    .page-header h1 {
        font-family: 'Poppins', sans-serif !important;
        font-size: 30px !important;
        font-weight: 800 !important;
        color: #ffffff !important;
        margin: 0 0 6px !important;
    }
    .page-header p {
        color: #94a3b8 !important;
        font-size: 14px !important;
        margin: 0 !important;
    }

    /* ── GLASS CARD ── */
    .glass-card {
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 18px;
        padding: 28px;
        margin-bottom: 22px;
        backdrop-filter: blur(12px);
    }

    /* ── STAT BOXES ── */
    .stat-row { display: flex; gap: 16px; margin-bottom: 22px; flex-wrap: wrap; }
    .stat-box {
        flex: 1;
        min-width: 140px;
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 14px;
        padding: 20px 16px;
        text-align: center;
    }
    .stat-box .stat-num {
        font-family: 'Poppins', sans-serif;
        font-size: 28px;
        font-weight: 700;
        color: #a78bfa;
    }
    .stat-box .stat-label {
        font-size: 12px;
        color: #94a3b8;
        margin-top: 4px;
    }

    /* ── BADGE ── */
    .badge-critical { background:#fee2e2; color:#dc2626; padding:4px 14px; border-radius:999px; font-size:12px; font-weight:600; display:inline-block; }
    .badge-moderate { background:#fef3c7; color:#d97706; padding:4px 14px; border-radius:999px; font-size:12px; font-weight:600; display:inline-block; }
    .badge-mild     { background:#d1fae5; color:#059669; padding:4px 14px; border-radius:999px; font-size:12px; font-weight:600; display:inline-block; }

    /* ── RESULT CARD ── */
    .result-critical {
        background: linear-gradient(135deg, rgba(239,68,68,0.15), rgba(220,38,38,0.05));
        border: 1px solid rgba(239,68,68,0.4);
        border-radius: 16px; padding: 24px; margin: 16px 0;
    }
    .result-moderate {
        background: linear-gradient(135deg, rgba(245,158,11,0.15), rgba(217,119,6,0.05));
        border: 1px solid rgba(245,158,11,0.4);
        border-radius: 16px; padding: 24px; margin: 16px 0;
    }
    .result-mild {
        background: linear-gradient(135deg, rgba(16,185,129,0.15), rgba(5,150,105,0.05));
        border: 1px solid rgba(16,185,129,0.4);
        border-radius: 16px; padding: 24px; margin: 16px 0;
    }

    /* ── ROUTE PILL ── */
    .route-container { display:flex; flex-wrap:wrap; align-items:center; gap:8px; margin:12px 0; }
    .route-node {
        background: rgba(99,102,241,0.2);
        border: 1px solid rgba(99,102,241,0.4);
        color: #a5b4fc !important;
        padding: 6px 14px;
        border-radius: 999px;
        font-size: 13px;
        font-weight: 500;
    }
    .route-arrow { color: #6366f1; font-size: 18px; }

    /* ── INPUTS ── */
    .stTextInput input, .stNumberInput input, .stSelectbox div[data-baseweb] {
        background: rgba(255,255,255,0.07) !important;
        border: 1px solid rgba(255,255,255,0.15) !important;
        border-radius: 10px !important;
        color: #f1f5f9 !important;
    }
    .stTextInput label, .stNumberInput label, .stSelectbox label {
        color: #94a3b8 !important;
        font-size: 13px !important;
    }

    /* ── BUTTON ── */
    .stButton > button {
        background: linear-gradient(135deg, #6366f1, #8b5cf6) !important;
        color: white !important;
        border: none !important;
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-size: 15px !important;
        padding: 12px 24px !important;
        transition: all 0.2s !important;
        box-shadow: 0 4px 15px rgba(99,102,241,0.3) !important;
    }
    .stButton > button:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(99,102,241,0.5) !important;
    }

    /* ── TABLES ── */
    table { border-collapse: collapse !important; width: 100% !important; }
    thead tr { background: rgba(99,102,241,0.3) !important; }
    thead th { color: #ffffff !important; padding: 12px !important; font-size: 13px !important; }
    tbody tr { background: rgba(255,255,255,0.03) !important; }
    tbody tr:hover { background: rgba(255,255,255,0.07) !important; }
    td { color: #e2e8f0 !important; padding: 11px 12px !important; font-size: 13px !important; border-bottom: 1px solid rgba(255,255,255,0.06) !important; }

    /* ── MISC ── */
    h2, h3 { color: #f1f5f9 !important; font-family: 'Poppins', sans-serif !important; }
    p, span, label { color: #cbd5e1 !important; }
    .disclaimer { font-size: 11px; color: #64748b !important; text-align: center; margin-top: 16px; font-style: italic; }
    hr { border-color: rgba(255,255,255,0.08) !important; }
</style>
"""
