import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    accuracy_score, 
    confusion_matrix,
    classification_report
)
import pickle
import matplotlib.pyplot as plt

# LOAD DATASET
df = pd.read_csv("triage_dataset.csv")
X = df['symptoms']
y = df['urgency']

# NLP / TEXT VECTORIZATION

vectorizer = TfidfVectorizer(
    ngram_range=(1,2),
    stop_words='english'
)

X_vectorized = vectorizer.fit_transform(X)

# SPLIT DATA
X_train, X_test, y_train, y_test = train_test_split(
    X_vectorized,
    y,
    test_size=0.2,
    random_state=42
)

# TRAIN KNN

model = KNeighborsClassifier(
    n_neighbors=5,
    weights='distance'
)

model.fit(X_train, y_train)

# TEST MODEL

preds = model.predict(X_test)

acc = accuracy_score(y_test, preds)

cm  = confusion_matrix(y_test, preds)

plt.figure(figsize=(5,5))
plt.imshow(cm)
plt.xticks(
    [0,1,2],
    ['Ctritical', 'Mild', 'Moderate']
)

plt.yticks(
    [0,1,2],
    ['Ctritical','Mild','Moderate']
)

plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.colorbar()
plt.savefig("confusion_matrix.png")
plt.show()

print("\nAccuracy:\n", acc)
print("\nConfusion Matrix:\n", cm)

# SAVE MODEL

pickle.dump(
    model,
    open(
        "knn_model.pkl",
        "wb"
    )
)

pickle.dump(
    vectorizer,
    open(
        "vectorizer.pkl",
        "wb"
    )
)

print("\nMODEL SAVED SUCCESSFULLY")