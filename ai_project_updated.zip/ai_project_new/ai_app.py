import streamlit as st
import pandas as pd
import time
import pickle
from bfs import *

# ── Load Model ──────────────────────────────────────────────────────────────
model = pickle.load(open("knn_model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

# ── Page Config ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="AI Patient Triage System",
    page_icon="💊",
    layout="wide"
)

from ai_style import CUSTOM_CSS
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)

# ── Session State ────────────────────────────────────────────────────────────
if "patient_records" not in st.session_state:
    st.session_state.patient_records = []
if "page" not in st.session_state:
    st.session_state.page = "🏠 Home"

# ── Sidebar Navigation ───────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("""
    <div class="sidebar-logo">
        <div style="font-size:42px">💊</div>
        <h2>MediTriage AI</h2>
        <p>Clinical Screening Engine</p>
    </div>
    """, unsafe_allow_html=True)

    pages = ["🏠 Home", "🩺 Patient Triage", "📋 Patient Records", "📊 Analytics", "ℹ️ About"]
    for p in pages:
        if st.button(p, key=p, use_container_width=True):
            st.session_state.page = p

    st.markdown("<br>", unsafe_allow_html=True)
    total = len(st.session_state.patient_records)
    critical = sum(1 for r in st.session_state.patient_records if r["Assigned Priority"] == "Critical")
    st.markdown(f"""
    <div style="padding:16px;background:rgba(255,255,255,0.04);border-radius:12px;border:1px solid rgba(255,255,255,0.08)">
        <p style="font-size:11px;color:#64748b;margin:0 0 10px">LIVE SESSION STATS</p>
        <p style="margin:4px 0;font-size:13px">🧑‍⚕️ Total Patients: <b style="color:#a78bfa">{total}</b></p>
        <p style="margin:4px 0;font-size:13px">🚨 Critical Cases: <b style="color:#f87171">{critical}</b></p>
    </div>
    """, unsafe_allow_html=True)

page = st.session_state.page

# ════════════════════════════════════════════════════════════════════════════
# PAGE 1 — HOME
# ════════════════════════════════════════════════════════════════════════════
if page == "🏠 Home":
    st.markdown("""
    <div class="page-header">
        <h1>💊 AI Patient Triage System</h1>
        <p>Intelligent clinical screening powered by K-Nearest Neighbours & BFS pathfinding</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown("""
        <div class="glass-card" style="text-align:center">
            <div style="font-size:36px">🤖</div>
            <h3 style="margin:10px 0 6px">KNN Classifier</h3>
            <p style="font-size:13px;color:#94a3b8">TF-IDF vectorized symptom text classified using K-Nearest Neighbours to predict urgency level.</p>
        </div>""", unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="glass-card" style="text-align:center">
            <div style="font-size:36px">🗺️</div>
            <h3 style="margin:10px 0 6px">BFS Pathfinding</h3>
            <p style="font-size:13px;color:#94a3b8">Breadth-First Search finds the shortest hospital route from Reception to the assigned department.</p>
        </div>""", unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div class="glass-card" style="text-align:center">
            <div style="font-size:36px">⚡</div>
            <h3 style="margin:10px 0 6px">Rule-Based Override</h3>
            <p style="font-size:13px;color:#94a3b8">Automatic urgency escalation for patients aged 60+ as a safety-first clinical rule.</p>
        </div>""", unsafe_allow_html=True)

    st.markdown("""
    <div class="glass-card">
        <h3>🏥 How It Works</h3>
        <p>1. &nbsp;Patient details and symptoms are entered in the <b>Patient Triage</b> page.</p>
        <p>2. &nbsp;The KNN model predicts an urgency tier: <b>Mild</b>, <b>Moderate</b>, or <b>Critical</b>.</p>
        <p>3. &nbsp;BFS computes the optimal hospital navigation route to the correct department.</p>
        <p>4. &nbsp;All cases are logged and visualized in <b>Patient Records</b> and <b>Analytics</b>.</p>
    </div>""", unsafe_allow_html=True)

    if st.button("🩺 Start Patient Triage →", use_container_width=True):
        st.session_state.page = "🩺 Patient Triage"
        st.rerun()

# ════════════════════════════════════════════════════════════════════════════
# PAGE 2 — PATIENT TRIAGE
# ════════════════════════════════════════════════════════════════════════════
elif page == "🩺 Patient Triage":
    st.markdown("""
    <div class="page-header">
        <h1>🩺 Patient Triage</h1>
        <p>Enter patient details and describe symptoms to receive an AI-powered urgency assessment</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="glass-card">', unsafe_allow_html=True)
    st.markdown("#### 👤 Patient Information")
    col1, col2, col3 = st.columns([2, 1, 1])
    with col1:
        p_name = st.text_input("Patient Full Name", placeholder="e.g., Zainab Ahmed", key="input_name")
    with col2:
        p_age = st.number_input("Age", min_value=0, max_value=120, value=22, step=1, key="input_age")
    with col3:
        p_gender = st.selectbox("Gender", ["Female", "Male", "Other"], key="input_gender")

    st.markdown("#### 🔍 Symptom Description")
    user_symptom_input = st.text_input(
        "Describe the patient's current symptoms",
        placeholder="e.g., Experiencing severe chest pain and mild fever...",
        key="input_symptoms"
    )
    submit_patient = st.button("➕ Run Diagnostic Analysis", use_container_width=True)
    st.markdown('</div>', unsafe_allow_html=True)

    # ── Medical Knowledge Base ──
    medical_knowledge_base = {
        "fever":   {"disease": "Mild Fever / Pyrexia", "medicines": ["Paracetamol (Panadol / Calpol)", "Ibuprofen (Brufen)"], "advice": "Keep well hydrated, monitor body temperature regularly, and rest.", "base_urgency": "Mild"},
        "cough":   {"disease": "Respiratory Cough & Congestion", "medicines": ["Cough Suppressant Syrup (Hydryllin / Mucaine)", "Lozenges (Strepsils)"], "advice": "Drink warm fluids, avoid cold drinks, and consider steam inhalation.", "base_urgency": "Mild"},
        "flu":     {"disease": "Common Influenza / Cold", "medicines": ["Antihistamines (Surbex / Arinac / Fexet)", "Paracetamol for aches"], "advice": "Increase Vitamin C fluid intake and take plenty of bed rest.", "base_urgency": "Mild"},
        "pain":    {"disease": "Acute Chest Pain / Cardiac Profile", "medicines": ["Aspirin (Disprin - Chewable Immediately)", "Glyceryl Trinitrate (GTN Spray)"], "advice": "Sit down comfortably, minimize physical exertion, and call an emergency ambulance.", "base_urgency": "Critical"},
        "stomach": {"disease": "Gastric Acidity / Spasms", "medicines": ["Antacids (Gaviscon / Mucaine Syrup)", "Omeprazole (Risek)"], "advice": "Avoid spicy or oily foods. Drink plenty of plain water.", "base_urgency": "Moderate"},
    }
    wait_times_table = {
        "Critical": "Immediate Attention (0–5 Mins)",
        "Moderate": "Semi-Urgent (30 Mins Expected Wait)",
        "Mild":     "Standard Non-Urgent (2 Hours Expected Wait)"
    }

    if submit_patient:
        if not p_name.strip():
            st.error("⚠️ Please enter a valid patient name.")
        elif not user_symptom_input.strip():
            st.error("⚠️ Please describe the patient's symptoms.")
        else:
            with st.spinner("Running AI diagnostic analysis..."):
                time.sleep(1)

            clean_query = user_symptom_input.lower()
            input_vector = vectorizer.transform([clean_query])
            probabilities = model.predict_proba(input_vector)[0]
            confidence = max(probabilities)
            highest_urgency_tier = model.predict(input_vector)[0]

            age_bump_applied = False
            if p_age >= 60:
                age_bump_applied = True
                if highest_urgency_tier == "Mild":
                    highest_urgency_tier = "Moderate"
                elif highest_urgency_tier == "Moderate":
                    highest_urgency_tier = "Critical"

            computed_wait_metric = wait_times_table[highest_urgency_tier]
            target_department = department_map[highest_urgency_tier]
            route = bfs_route("Reception", target_department)

            badge_map = {"Critical": "badge-critical", "Moderate": "badge-moderate", "Mild": "badge-mild"}
            result_map = {"Critical": "result-critical", "Moderate": "result-moderate", "Mild": "result-mild"}
            icon_map   = {"Critical": "🚨", "Moderate": "⚠️", "Mild": "✅"}

            st.markdown(f'<div class="{result_map[highest_urgency_tier]}">', unsafe_allow_html=True)
            st.markdown(f"### {icon_map[highest_urgency_tier]} Diagnostic Result for **{p_name}**")

            c1, c2, c3 = st.columns(3)
            c1.metric("Urgency Tier", highest_urgency_tier)
            c2.metric("AI Confidence", f"{confidence*100:.1f}%")
            c3.metric("Department", target_department)

            st.markdown(f"**⏱️ Expected Wait:** {computed_wait_metric}")

            if age_bump_applied:
                st.warning(f"👵 Geriatric Safety Lift Applied — patient is {p_age} years old. Urgency escalated automatically.")
            if confidence < 0.4:
                st.warning("⚠️ Low confidence prediction. Additional clinical information recommended.")

            st.markdown("**🛣️ Hospital Route:**")
            route_html = '<div class="route-container">'
            for i, node in enumerate(route):
                route_html += f'<span class="route-node">{node}</span>'
                if i < len(route) - 1:
                    route_html += '<span class="route-arrow">→</span>'
            route_html += '</div>'
            st.markdown(route_html, unsafe_allow_html=True)

            matched_words = clean_query.split()
            st.markdown(f"**🎯 Detected Symptom Words:** `{', '.join(matched_words)}`")
            st.markdown('</div>', unsafe_allow_html=True)

            st.session_state.patient_records.append({
                "Patient Name": p_name,
                "Age": p_age,
                "Gender": p_gender,
                "Symptoms": clean_query,
                "Assigned Priority": highest_urgency_tier,
                "Expected Wait": computed_wait_metric.split(" (")[0],
                "Department": target_department,
                "Confidence": f"{confidence*100:.1f}%"
            })

            st.markdown('<p class="disclaimer">Prototype Notice: Always verify recommendations with qualified medical professionals before treatment.</p>', unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# PAGE 3 — PATIENT RECORDS
# ════════════════════════════════════════════════════════════════════════════
elif page == "📋 Patient Records":
    st.markdown("""
    <div class="page-header">
        <h1>📋 Patient Records</h1>
        <p>All patients evaluated during this session</p>
    </div>
    """, unsafe_allow_html=True)

    if not st.session_state.patient_records:
        st.markdown("""
        <div class="glass-card" style="text-align:center;padding:48px">
            <div style="font-size:48px">📭</div>
            <h3>No Records Yet</h3>
            <p style="color:#64748b">Go to Patient Triage to evaluate patients.</p>
        </div>""", unsafe_allow_html=True)
    else:
        total = len(st.session_state.patient_records)
        critical = sum(1 for r in st.session_state.patient_records if r["Assigned Priority"] == "Critical")
        moderate = sum(1 for r in st.session_state.patient_records if r["Assigned Priority"] == "Moderate")
        mild = sum(1 for r in st.session_state.patient_records if r["Assigned Priority"] == "Mild")

        st.markdown(f"""
        <div class="stat-row">
            <div class="stat-box"><div class="stat-num">{total}</div><div class="stat-label">Total Patients</div></div>
            <div class="stat-box"><div class="stat-num" style="color:#f87171">{critical}</div><div class="stat-label">Critical</div></div>
            <div class="stat-box"><div class="stat-num" style="color:#fbbf24">{moderate}</div><div class="stat-label">Moderate</div></div>
            <div class="stat-box"><div class="stat-num" style="color:#34d399">{mild}</div><div class="stat-label">Mild</div></div>
        </div>""", unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        df = pd.DataFrame(st.session_state.patient_records)
        st.table(df)
        st.markdown('</div>', unsafe_allow_html=True)

        if st.button("♻️ Clear All Records", use_container_width=True):
            st.session_state.patient_records = []
            st.rerun()

# ════════════════════════════════════════════════════════════════════════════
# PAGE 4 — ANALYTICS
# ════════════════════════════════════════════════════════════════════════════
elif page == "📊 Analytics":
    st.markdown("""
    <div class="page-header">
        <h1>📊 Analytics Dashboard</h1>
        <p>Visual breakdown of patient triage data from this session</p>
    </div>
    """, unsafe_allow_html=True)

    if not st.session_state.patient_records:
        st.markdown("""
        <div class="glass-card" style="text-align:center;padding:48px">
            <div style="font-size:48px">📊</div>
            <h3>No Data Yet</h3>
            <p style="color:#64748b">Evaluate some patients first to see analytics.</p>
        </div>""", unsafe_allow_html=True)
    else:
        df = pd.DataFrame(st.session_state.patient_records)

        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown("#### 🎯 Priority Distribution")
            counts = df["Assigned Priority"].value_counts()
            st.bar_chart(counts)
            st.markdown('</div>', unsafe_allow_html=True)

        with col2:
            st.markdown('<div class="glass-card">', unsafe_allow_html=True)
            st.markdown("#### 🏥 Department Distribution")
            dept_counts = df["Department"].value_counts()
            st.bar_chart(dept_counts)
            st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("#### 👥 Age Distribution by Priority")
        st.bar_chart(df.groupby("Assigned Priority")["Age"].mean())
        st.markdown('</div>', unsafe_allow_html=True)

        st.markdown('<div class="glass-card">', unsafe_allow_html=True)
        st.markdown("#### 🖼️ Model Confusion Matrix")
        try:
            st.image("confusion_matrix.png", caption="KNN Model Confusion Matrix", use_container_width=True)
        except:
            st.info("Confusion matrix image not found.")
        st.markdown('</div>', unsafe_allow_html=True)

# ════════════════════════════════════════════════════════════════════════════
# PAGE 5 — ABOUT
# ════════════════════════════════════════════════════════════════════════════
elif page == "ℹ️ About":
    st.markdown("""
    <div class="page-header">
        <h1>ℹ️ About This System</h1>
        <p>Technical overview of the AI Patient Triage System</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("""
        <div class="glass-card">
            <h3>🤖 Machine Learning</h3>
            <p><b>Algorithm:</b> K-Nearest Neighbours (KNN)</p>
            <p><b>Vectorizer:</b> TF-IDF (1-gram + 2-gram)</p>
            <p><b>Output Classes:</b> Mild · Moderate · Critical</p>
            <p><b>Training:</b> Symptom text dataset with urgency labels</p>
            <p><b>Special Rule:</b> Patients 60+ auto-escalated one urgency tier</p>
        </div>""", unsafe_allow_html=True)

    with col2:
        st.markdown("""
        <div class="glass-card">
            <h3>🗺️ BFS Pathfinding</h3>
            <p><b>Algorithm:</b> Breadth-First Search</p>
            <p><b>Start Node:</b> Reception</p>
            <p><b>Graph:</b> Hospital department network</p>
            <p><b>Mild →</b> General OPD</p>
            <p><b>Moderate →</b> Internal Medicine</p>
            <p><b>Critical →</b> Emergency → ICU</p>
        </div>""", unsafe_allow_html=True)

    st.markdown("""
    <div class="glass-card">
        <h3>🛠️ Tech Stack</h3>
        <p>🐍 <b>Python 3.13</b> &nbsp;|&nbsp; 📊 <b>Streamlit</b> — Web UI &nbsp;|&nbsp; 🧠 <b>scikit-learn</b> — KNN Model &nbsp;|&nbsp; 📐 <b>pandas</b> — Data handling &nbsp;|&nbsp; 🔍 <b>TF-IDF</b> — NLP Vectorization</p>
        <hr>
        <p class="disclaimer">This is a prototype educational system. All recommendations must be verified by qualified medical professionals.</p>
    </div>""", unsafe_allow_html=True)
