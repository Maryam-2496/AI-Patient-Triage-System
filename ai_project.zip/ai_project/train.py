import matplotlib
matplotlib.use('Agg')
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    accuracy_score, 
    confusion_matrix,
    classification_report
)
import pickle
import matplotlib.pyplot as plt
import numpy as np

# LOAD DATASET
df = pd.read_csv("triage_dataset.csv")
X = df['symptoms']
y = df['urgency']

# NLP / TEXT VECTORIZATION

vectorizer = TfidfVectorizer(
    ngram_range=(1,2),
    stop_words='english'
)

X_vectorized = vectorizer.fit_transform(X)

# SPLIT DATA
X_train, X_test, y_train, y_test = train_test_split(
    X_vectorized,
    y,
    test_size=0.2,
    random_state=42
)

# TRAIN KNN

model = KNeighborsClassifier(
    n_neighbors=5,
    weights='distance'
)

model.fit(X_train, y_train)

# TEST MODEL

preds = model.predict(X_test)

acc = accuracy_score(y_test, preds)

labels = ['Critical', 'Mild', 'Moderate']
cm = confusion_matrix(y_test, preds, labels=labels)

# PLOT CONFUSION MATRIX WITH CELL ANNOTATIONS

fig, ax = plt.subplots(figsize=(7, 6))
fig.patch.set_facecolor('#1a1a2e')
ax.set_facecolor('#1a1a2e')

im = ax.imshow(cm, interpolation="nearest", cmap='Blues')

# Add number annotations inside each cell
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        val = cm[i, j]
        color = "white" if val < cm.max() / 2 else "black"
        ax.text(j, i, str(val), ha="center", va="center",
                fontsize=16, fontweight='bold', color=color)

cbar = plt.colorbar(im, ax=ax)
cbar.ax.yaxis.set_tick_params(color='white')
plt.setp(cbar.ax.yaxis.get_ticklabels(), color='white')

ax.set_title("KNN Confusion Matrix", fontsize=14, fontweight='bold',
             color='white', pad=15)

ax.set_xticks([0, 1, 2])
ax.set_xticklabels(labels, color='white', fontsize=11)
ax.set_yticks([0, 1, 2])
ax.set_yticklabels(labels, color='white', fontsize=11)

ax.set_xlabel("Predicted", color='white', fontsize=12, labelpad=10)
ax.set_ylabel("Actual", color='white', fontsize=12, labelpad=10)

ax.tick_params(colors='white')
for spine in ax.spines.values():
    spine.set_edgecolor('#444466')

plt.tight_layout()

plt.savefig(
    "confusion_matrix.png",
    dpi=300,
    bbox_inches="tight",
    facecolor='#1a1a2e'
)

plt.close("all")

print("\nAccuracy:\n", acc)
print("\nConfusion Matrix:\n", cm)

# SAVE MODEL

pickle.dump(
    model,
    open(
        "knn_model.pkl",
        "wb"
    )
)

pickle.dump(
    vectorizer,
    open(
        "vectorizer.pkl",
        "wb"
    )
)

print("\nMODEL SAVED SUCCESSFULLY")
